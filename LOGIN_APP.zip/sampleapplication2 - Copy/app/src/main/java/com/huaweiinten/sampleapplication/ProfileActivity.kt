package com.huaweiinten.sampleapplication

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.huaweiinten.sampleapplication.R

class ProfileActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_profile)
    }
}